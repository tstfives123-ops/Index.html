'use client'

import { useState, useEffect } from 'react'

interface NavigationProps {
  section: number
  scrollProgress: number
}

export function Navigation({ section, scrollProgress }: NavigationProps) {
  const [isVisible, setIsVisible] = useState(false)

  useEffect(() => {
    const handleScroll = () => {
      setIsVisible(window.scrollY > 100)
    }
    window.addEventListener('scroll', handleScroll, { passive: true })
    return () => window.removeEventListener('scroll', handleScroll)
  }, [])

  const sections = [
    { id: 'hero', label: 'Home', icon: '◆' },
    { id: 'journey', label: 'Journey', icon: '◇' },
    { id: 'contact', label: 'Contact', icon: '◇' },
  ]

  const scrollToSection = (index: number) => {
    const docHeight = document.documentElement.scrollHeight - window.innerHeight
    const targetScroll = (index / (sections.length - 1)) * docHeight
    window.scrollTo({ top: targetScroll, behavior: 'smooth' })
  }

  return (
    <>
      {/* Top Navigation */}
      <nav
        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${
          isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 -translate-y-full'
        }`}
      >
        <div className="glass-panel mx-4 mt-4 rounded-2xl px-6 py-3 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="text-cosmic-neon-cyan font-bold text-lg tracking-wider">HMZ</span>
            <span className="text-white/40 text-xs">hamzadigital.fun</span>
          </div>

          <div className="flex items-center gap-6">
            {sections.map((s, i) => (
              <button
                key={s.id}
                onClick={() => scrollToSection(i)}
                className={`text-sm transition-all duration-300 ${
                  section === i
                    ? 'text-cosmic-neon-cyan font-medium'
                    : 'text-white/50 hover:text-white/80'
                }`}
              >
                {s.label}
              </button>
            ))}
          </div>
        </div>
      </nav>

      {/* Side Progress Indicator */}
      <div className="fixed right-6 top-1/2 -translate-y-1/2 z-50 flex flex-col items-center gap-4">
        {sections.map((s, i) => (
          <button
            key={s.id}
            onClick={() => scrollToSection(i)}
            className="group flex items-center gap-3"
          >
            <span
              className={`text-[10px] transition-all duration-300 ${
                section === i ? 'text-cosmic-neon-cyan opacity-100' : 'text-white/0 group-hover:text-white/50'
              }`}
            >
              {s.label}
            </span>
            <div
              className={`w-2 h-2 rounded-full transition-all duration-300 ${
                section === i
                  ? 'bg-cosmic-neon-cyan shadow-[0_0_10px_#00f0ff] scale-150'
                  : 'bg-white/20 hover:bg-white/40'
              }`}
            />
          </button>
        ))}
      </div>

      {/* Scroll Progress Bar */}
      <div className="fixed bottom-0 left-0 right-0 z-50 h-0.5 bg-white/10">
        <div
          className="h-full transition-all duration-100"
          style={{
            width: `${scrollProgress * 100}%`,
            background: 'linear-gradient(90deg, #00f0ff, #b026ff, #ff00ff)',
          }}
        />
      </div>
    </>
  )
}
