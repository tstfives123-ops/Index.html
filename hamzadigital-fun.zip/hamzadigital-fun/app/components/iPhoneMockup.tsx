'use client'

import { useRef, useState } from 'react'
import { useFrame } from '@react-three/fiber'
import { RoundedBox, Text, Html } from '@react-three/drei'
import * as THREE from 'three'

interface iPhoneMockupProps {
  position?: [number, number, number]
  rotation?: [number, number, number]
  scale?: number
  screenContent?: 'hero' | 'journey' | 'contact'
  floatIntensity?: number
}

export function iPhoneMockup({
  position = [4, 0, 0],
  rotation = [0, -0.3, 0],
  scale = 1,
  screenContent = 'hero',
  floatIntensity = 0.5,
}: iPhoneMockupProps) {
  const groupRef = useRef<THREE.Group>(null)
  const [hovered, setHovered] = useState(false)

  useFrame((state) => {
    if (groupRef.current) {
      groupRef.current.position.y = position[1] + Math.sin(state.clock.elapsedTime * 0.8) * floatIntensity * 0.2

      if (hovered) {
        groupRef.current.rotation.y += 0.01
      }
    }
  })

  const phoneWidth = 1.8
  const phoneHeight = 3.8
  const phoneDepth = 0.15
  const cornerRadius = 0.2

  return (
    <group
      ref={groupRef}
      position={position}
      rotation={rotation}
      scale={scale}
      onPointerOver={() => setHovered(true)}
      onPointerOut={() => setHovered(false)}
    >
      {/* Phone body */}
      <RoundedBox
        args={[phoneWidth, phoneHeight, phoneDepth]}
        radius={cornerRadius}
        smoothness={4}
      >
        <meshPhysicalMaterial
          color="#1a1a2e"
          metalness={0.8}
          roughness={0.2}
          clearcoat={1}
          clearcoatRoughness={0.1}
        />
      </RoundedBox>

      {/* Screen */}
      <mesh position={[0, 0, phoneDepth / 2 + 0.001]}>
        <planeGeometry args={[phoneWidth - 0.15, phoneHeight - 0.3]} />
        <meshBasicMaterial color="#0a0a1a" />
      </mesh>

      {/* Dynamic Island */}
      <mesh position={[0, phoneHeight / 2 - 0.15, phoneDepth / 2 + 0.002]}>
        <capsuleGeometry args={[0.06, 0.2, 4, 8]} />
        <meshBasicMaterial color="#000000" />
      </mesh>

      {/* Screen Content */}
      <Html
        position={[0, 0, phoneDepth / 2 + 0.003]}
        transform
        occlude
        style={{
          width: `${(phoneWidth - 0.15) * 160}px`,
          height: `${(phoneHeight - 0.3) * 160}px`,
          pointerEvents: 'none',
        }}
      >
        <div className="w-full h-full flex flex-col items-center justify-center text-white p-3">
          {screenContent === 'hero' && (
            <div className="flex flex-col items-center gap-2 text-center">
              <div className="text-cosmic-neon-cyan font-bold text-lg tracking-wider">HMZ</div>
              <div className="text-xs font-light tracking-wide leading-tight">
                DIGITAL ARCHITECT<br/>& CREATIVE MIND
              </div>
              <div className="mt-2 px-3 py-1 rounded-full text-[8px] font-medium"
                style={{
                  background: 'linear-gradient(135deg, #00f0ff, #b026ff)',
                  boxShadow: '0 0 10px rgba(0, 240, 255, 0.5)'
                }}
              >
                EXPLORE JOURNEY
              </div>
            </div>
          )}

          {screenContent === 'journey' && (
            <div className="flex flex-col items-start gap-2 w-full">
              <div className="text-cosmic-neon-cyan font-bold text-sm">Journey</div>
              <div className="w-full space-y-2">
                {[
                  { icon: '🌱', title: 'Childhood Curiosity', active: true },
                  { icon: '🌐', title: 'First Internet', active: false },
                  { icon: '🎓', title: 'Academic Awakening', active: false },
                  { icon: '🚀', title: 'Building Future', active: false },
                ].map((item, i) => (
                  <div key={i} className={`flex items-center gap-2 p-1.5 rounded-lg text-[8px] ${
                    item.active 
                      ? 'bg-cosmic-purple/30 border border-cosmic-neon-cyan/50' 
                      : 'bg-white/5'
                  }`}>
                    <span className="text-xs">{item.icon}</span>
                    <span className={item.active ? 'text-cosmic-neon-cyan' : 'text-white/60'}>
                      {item.title}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {screenContent === 'contact' && (
            <div className="flex flex-col items-center gap-2 w-full">
              <div className="text-cosmic-neon-cyan font-bold text-sm">Contact</div>
              <div className="w-full space-y-1.5">
                <div className="w-full h-5 bg-white/10 rounded text-[7px] flex items-center px-2 text-white/40">
                  Name
                </div>
                <div className="w-full h-5 bg-white/10 rounded text-[7px] flex items-center px-2 text-white/40">
                  Email
                </div>
                <div className="w-full h-12 bg-white/10 rounded text-[7px] flex items-start p-2 text-white/40">
                  Message
                </div>
              </div>
              <div className="mt-1 px-4 py-1 rounded-full text-[8px] font-medium"
                style={{
                  background: 'linear-gradient(135deg, #00f0ff, #b026ff)',
                }}
              >
                Send Message
              </div>
            </div>
          )}
        </div>
      </Html>

      {/* Side buttons */}
      <mesh position={[phoneWidth / 2 + 0.02, phoneHeight / 4, 0]}>
        <boxGeometry args={[0.02, 0.4, 0.05]} />
        <meshPhysicalMaterial color="#2a2a3e" metalness={0.9} roughness={0.2} />
      </mesh>
      <mesh position={[phoneWidth / 2 + 0.02, phoneHeight / 4 - 0.5, 0]}>
        <boxGeometry args={[0.02, 0.3, 0.05]} />
        <meshPhysicalMaterial color="#2a2a3e" metalness={0.9} roughness={0.2} />
      </mesh>

      {/* Rim light glow */}
      {hovered && (
        <mesh position={[0, 0, 0]}>
          <RoundedBox args={[phoneWidth + 0.1, phoneHeight + 0.1, phoneDepth + 0.1]} radius={cornerRadius + 0.02}>
            <meshBasicMaterial
              color="#00f0ff"
              transparent
              opacity={0.1}
              side={THREE.BackSide}
            />
          </RoundedBox>
        </mesh>
      )}
    </group>
  )
}
