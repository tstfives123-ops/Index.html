'use client'

import { useRef, useMemo, useState } from 'react'
import { useFrame } from '@react-three/fiber'
import { Text3D, Center, Float } from '@react-three/drei'
import * as THREE from 'three'

interface HMZLogoProps {
  mousePosition?: { x: number; y: number }
}

export function HMZLogo({ mousePosition = { x: 0, y: 0 } }: HMZLogoProps) {
  const groupRef = useRef<THREE.Group>(null)
  const ringsRef = useRef<THREE.Group>(null)
  const [hovered, setHovered] = useState(false)

  // Create orbital rings
  const rings = useMemo(() => {
    return [
      { radius: 3.5, tube: 0.03, speed: 0.3, tilt: 0.2, color: '#00f0ff' },
      { radius: 4.2, tube: 0.02, speed: -0.2, tilt: -0.3, color: '#b026ff' },
      { radius: 3.8, tube: 0.025, speed: 0.15, tilt: 0.5, color: '#ff00ff' },
    ]
  }, [])

  useFrame((state) => {
    if (groupRef.current) {
      // Gentle idle rotation
      groupRef.current.rotation.y += 0.002

      // Mouse parallax
      groupRef.current.rotation.x = mousePosition.y * 0.3
      groupRef.current.rotation.z = mousePosition.x * 0.2

      // Float animation
      groupRef.current.position.y = Math.sin(state.clock.elapsedTime * 0.5) * 0.3
    }

    if (ringsRef.current) {
      ringsRef.current.children.forEach((ring, i) => {
        ring.rotation.x += rings[i].speed * 0.01
        ring.rotation.y += rings[i].speed * 0.005
      })
    }
  })

  return (
    <group ref={groupRef}>
      {/* Main HMZ Text */}
      <Center position={[0, 0, 0]}>
        <Float speed={1.5} rotationIntensity={0.1} floatIntensity={0.5}>
          <group
            onPointerOver={() => setHovered(true)}
            onPointerOut={() => setHovered(false)}
          >
            {/* Extruded 3D text with metallic material */}
            <Text3D
              font="/fonts/helvetiker_bold.typeface.json"
              size={2.5}
              height={0.8}
              curveSegments={12}
              bevelEnabled
              bevelThickness={0.05}
              bevelSize={0.03}
              bevelOffset={0}
              bevelSegments={5}
            >
              HMZ
              <meshPhysicalMaterial
                color={hovered ? '#ffffff' : '#e0e0ff'}
                metalness={0.9}
                roughness={0.1}
                clearcoat={1}
                clearcoatRoughness={0.1}
                emissive={hovered ? '#00f0ff' : '#1a0a2e'}
                emissiveIntensity={hovered ? 0.5 : 0.2}
              />
            </Text3D>

            {/* Inner glow layer */}
            <Text3D
              font="/fonts/helvetiker_bold.typeface.json"
              size={2.5}
              height={0.1}
              curveSegments={12}
              bevelEnabled
              bevelThickness={0.02}
              bevelSize={0.01}
              bevelOffset={0}
              bevelSegments={3}
            >
              HMZ
              <meshBasicMaterial
                color="#00f0ff"
                transparent
                opacity={0.3}
                side={THREE.BackSide}
              />
            </Text3D>
          </group>
        </Float>
      </Center>

      {/* Floating text above */}
      <Center position={[0, 3.5, 0]}>
        <Float speed={2} rotationIntensity={0.05} floatIntensity={0.3}>
          <Text3D
            font="/fonts/helvetiker_regular.typeface.json"
            size={0.4}
            height={0.1}
            curveSegments={8}
          >
            HAMZADIGITAL.FUN
            <meshBasicMaterial
              color="#00f0ff"
              transparent
              opacity={0.8}
            />
          </Text3D>
        </Float>
      </Center>

      {/* Orbital rings */}
      <group ref={ringsRef}>
        {rings.map((ring, i) => (
          <mesh
            key={i}
            rotation={[ring.tilt, 0, 0]}
          >
            <torusGeometry args={[ring.radius, ring.tube, 16, 100]} />
            <meshBasicMaterial
              color={ring.color}
              transparent
              opacity={0.6}
              side={THREE.DoubleSide}
            />
            {/* Glow ring */}
            <mesh rotation={[0, 0, 0]}>
              <torusGeometry args={[ring.radius, ring.tube * 3, 16, 100]} />
              <meshBasicMaterial
                color={ring.color}
                transparent
                opacity={0.1}
                side={THREE.DoubleSide}
                blending={THREE.AdditiveBlending}
              />
            </mesh>
          </mesh>
        ))}
      </group>
    </group>
  )
}
