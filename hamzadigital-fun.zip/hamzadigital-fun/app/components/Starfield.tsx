'use client'

import { useRef, useMemo } from 'react'
import { useFrame } from '@react-three/fiber'
import * as THREE from 'three'

interface StarfieldProps {
  count?: number
  mousePosition?: { x: number; y: number }
}

export function Starfield({ count = 10000, mousePosition = { x: 0, y: 0 } }: StarfieldProps) {
  const meshRef = useRef<THREE.InstancedMesh>(null)
  const materialRef = useRef<THREE.ShaderMaterial>(null)

  const { positions, sizes, colors, twinkleSpeed } = useMemo(() => {
    const positions = new Float32Array(count * 3)
    const sizes = new Float32Array(count)
    const colors = new Float32Array(count * 3)
    const twinkleSpeed = new Float32Array(count)

    const colorPalette = [
      new THREE.Color('#ffffff'),
      new THREE.Color('#a8d8ea'),
      new THREE.Color('#b4a7d6'),
      new THREE.Color('#d4a5a5'),
      new THREE.Color('#9ed2c6'),
      new THREE.Color('#00f0ff'),
      new THREE.Color('#b026ff'),
      new THREE.Color('#ff00ff'),
    ]

    for (let i = 0; i < count; i++) {
      const i3 = i * 3
      const radius = 50 + Math.random() * 100
      const theta = Math.random() * Math.PI * 2
      const phi = Math.acos(2 * Math.random() - 1)

      positions[i3] = radius * Math.sin(phi) * Math.cos(theta)
      positions[i3 + 1] = radius * Math.sin(phi) * Math.sin(theta)
      positions[i3 + 2] = radius * Math.cos(phi)

      sizes[i] = Math.random() * 2 + 0.5
      twinkleSpeed[i] = Math.random() * 3 + 1

      const color = colorPalette[Math.floor(Math.random() * colorPalette.length)]
      colors[i3] = color.r
      colors[i3 + 1] = color.g
      colors[i3 + 2] = color.b
    }

    return { positions, sizes, colors, twinkleSpeed }
  }, [count])

  const starShader = useMemo(() => ({
    uniforms: {
      uTime: { value: 0 },
      uMouse: { value: new THREE.Vector2(0, 0) },
    },
    vertexShader: `
      attribute float aSize;
      attribute vec3 aColor;
      attribute float aTwinkleSpeed;

      uniform float uTime;
      uniform vec2 uMouse;

      varying vec3 vColor;
      varying float vTwinkle;

      void main() {
        vColor = aColor;

        vec4 mvPosition = modelViewMatrix * vec4(position, 1.0);

        // Twinkle effect
        float twinkle = sin(uTime * aTwinkleSpeed + position.x * 0.1) * 0.5 + 0.5;
        vTwinkle = twinkle;

        // Mouse parallax
        vec3 pos = position;
        pos.x += uMouse.x * 2.0;
        pos.y += uMouse.y * 2.0;

        mvPosition = modelViewMatrix * vec4(pos, 1.0);

        gl_PointSize = aSize * twinkle * (300.0 / -mvPosition.z);
        gl_Position = projectionMatrix * mvPosition;
      }
    `,
    fragmentShader: `
      varying vec3 vColor;
      varying float vTwinkle;

      void main() {
        float dist = length(gl_PointCoord - vec2(0.5));
        if (dist > 0.5) discard;

        float alpha = 1.0 - smoothstep(0.0, 0.5, dist);
        alpha *= vTwinkle * 0.8 + 0.2;

        // Glow
        float glow = 1.0 - smoothstep(0.0, 0.3, dist);
        vec3 finalColor = vColor + vColor * glow * 2.0;

        gl_FragColor = vec4(finalColor, alpha);
      }
    `,
  }), [])

  useFrame((state) => {
    if (materialRef.current) {
      materialRef.current.uniforms.uTime.value = state.clock.elapsedTime
      materialRef.current.uniforms.uMouse.value.set(
        mousePosition.x * 5,
        mousePosition.y * 5
      )
    }
    if (meshRef.current) {
      meshRef.current.rotation.y += 0.0002
      meshRef.current.rotation.x += 0.0001
    }
  })

  return (
    <instancedMesh ref={meshRef} args={[undefined, undefined, count]}>
      <bufferGeometry>
        <bufferAttribute
          attach="attributes-position"
          count={count}
          array={positions}
          itemSize={3}
        />
        <bufferAttribute
          attach="attributes-aSize"
          count={count}
          array={sizes}
          itemSize={1}
        />
        <bufferAttribute
          attach="attributes-aColor"
          count={count}
          array={colors}
          itemSize={3}
        />
        <bufferAttribute
          attach="attributes-aTwinkleSpeed"
          count={count}
          array={twinkleSpeed}
          itemSize={1}
        />
      </bufferGeometry>
      <shaderMaterial
        ref={materialRef}
        {...starShader}
        transparent
        depthWrite={false}
        blending={THREE.AdditiveBlending}
      />
    </instancedMesh>
  )
}
