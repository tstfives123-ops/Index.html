'use client'

import { useRef, useMemo } from 'react'
import { useFrame, useThree } from '@react-three/fiber'
import { EffectComposer, Bloom, ChromaticAberration, Vignette, SMAA } from '@react-three/postprocessing'
import { Environment, ContactShadows } from '@react-three/drei'
import * as THREE from 'three'
import { Starfield } from './Starfield'
import { Nebula } from './Nebula'
import { BokehOrbs } from './BokehOrbs'
import { HMZLogo } from './HMZLogo'
import { iPhoneMockup } from './iPhoneMockup'
import { JourneyTimeline } from './JourneyTimeline'
import { ContactSection } from './ContactSection'

interface SceneProps {
  scrollProgress: number
  mousePosition: { x: number; y: number }
  section: number
}

export function Scene({ scrollProgress, mousePosition, section }: SceneProps) {
  const { camera } = useThree()
  const cameraRef = useRef(camera)

  // Camera path based on scroll
  useFrame(() => {
    if (!cameraRef.current) return

    // Smooth camera movement
    const targetX = Math.sin(scrollProgress * Math.PI * 2) * 2 + mousePosition.x * 3
    const targetY = -scrollProgress * 15 + mousePosition.y * 2
    const targetZ = 8 - scrollProgress * 3

    cameraRef.current.position.x += (targetX - cameraRef.current.position.x) * 0.03
    cameraRef.current.position.y += (targetY - cameraRef.current.position.y) * 0.03
    cameraRef.current.position.z += (targetZ - cameraRef.current.position.z) * 0.03

    cameraRef.current.lookAt(0, -scrollProgress * 8, 0)
  })

  return (
    <>
      {/* Lighting */}
      <ambientLight intensity={0.1} />
      <pointLight position={[10, 10, 10]} intensity={1} color="#00f0ff" />
      <pointLight position={[-10, -10, 5]} intensity={0.8} color="#b026ff" />
      <pointLight position={[0, 5, -10]} intensity={0.6} color="#ff00ff" />
      <directionalLight position={[5, 5, 5]} intensity={0.5} color="#ffffff" />

      {/* Volumetric god rays simulation */}
      <spotLight
        position={[0, 20, 0]}
        angle={0.5}
        penumbra={1}
        intensity={2}
        color="#7c3aed"
        castShadow
      />
      <spotLight
        position={[10, 15, 5]}
        angle={0.4}
        penumbra={0.8}
        intensity={1.5}
        color="#00f0ff"
      />

      {/* Background elements */}
      <Starfield count={10000} mousePosition={mousePosition} />

      <Nebula
        position={[-15, 5, -40]}
        scale={2}
        color1="#7c3aed"
        color2="#06b6d4"
        color3="#d946ef"
        opacity={0.3}
      />
      <Nebula
        position={[20, -5, -35]}
        scale={1.5}
        color1="#b026ff"
        color2="#00f0ff"
        color3="#ff00ff"
        opacity={0.25}
      />
      <Nebula
        position={[0, 15, -50]}
        scale={3}
        color1="#1a0a2e"
        color2="#7c3aed"
        color3="#00f0ff"
        opacity={0.2}
      />

      <BokehOrbs count={40} />

      {/* Hero Section */}
      <group position={[0, 0, 0]} visible={section === 0 || scrollProgress < 0.4}>
        <HMZLogo mousePosition={mousePosition} />
        <iPhoneMockup
          position={[4.5, -0.5, 1]}
          rotation={[0, -0.4, 0.1]}
          scale={0.9}
          screenContent="hero"
          floatIntensity={0.6}
        />
      </group>

      {/* Journey Section */}
      <group position={[0, -6, 0]} visible={section === 1 || (scrollProgress > 0.3 && scrollProgress < 0.7)}>
        <JourneyTimeline scrollProgress={scrollProgress} />
        <iPhoneMockup
          position={[-4, -2, 1]}
          rotation={[0, 0.3, -0.05]}
          scale={0.8}
          screenContent="journey"
          floatIntensity={0.4}
        />
      </group>

      {/* Contact Section */}
      <ContactSection scrollProgress={scrollProgress} />

      {/* Floating debris */}
      <FloatingDebris count={30} />

      {/* Post-processing */}
      <EffectComposer>
        <Bloom
          intensity={1.5}
          luminanceThreshold={0.2}
          luminanceSmoothing={0.9}
          mipmapBlur
        />
        <ChromaticAberration
          offset={[0.001, 0.001]}
          radialModulation
          modulationOffset={0.5}
        />
        <Vignette
          offset={0.3}
          darkness={0.7}
          eskil={false}
          blendFunction={2}
        />
        <SMAA />
      </EffectComposer>
    </>
  )
}

function FloatingDebris({ count = 30 }: { count?: number }) {
  const groupRef = useRef<THREE.Group>(null)

  const debris = useMemo(() => {
    return Array.from({ length: count }, () => ({
      position: [
        (Math.random() - 0.5) * 30,
        (Math.random() - 0.5) * 30,
        (Math.random() - 0.5) * 20,
      ] as [number, number, number],
      rotation: [Math.random() * Math.PI, Math.random() * Math.PI, Math.random() * Math.PI] as [number, number, number],
      scale: Math.random() * 0.1 + 0.02,
      speed: Math.random() * 0.2 + 0.1,
    }))
  }, [count])

  useFrame((state) => {
    if (!groupRef.current) return
    const time = state.clock.elapsedTime

    groupRef.current.children.forEach((child, i) => {
      const item = debris[i]
      child.rotation.x += item.speed * 0.01
      child.rotation.y += item.speed * 0.005
      child.position.y += Math.sin(time * item.speed + i) * 0.001
    })
  })

  return (
    <group ref={groupRef}>
      {debris.map((item, i) => (
        <mesh key={i} position={item.position} rotation={item.rotation} scale={item.scale}>
          <tetrahedronGeometry args={[1, 0]} />
          <meshPhysicalMaterial
            color="#2a2a3e"
            metalness={0.9}
            roughness={0.3}
            transparent
            opacity={0.6}
          />
        </mesh>
      ))}
    </group>
  )
}
