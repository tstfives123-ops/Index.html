'use client'

import { useRef, useState } from 'react'
import { useFrame } from '@react-three/fiber'
import { RoundedBox, Text, Float, Html } from '@react-three/drei'
import * as THREE from 'three'

interface ContactSectionProps {
  scrollProgress: number
}

export function ContactSection({ scrollProgress }: ContactSectionProps) {
  const groupRef = useRef<THREE.Group>(null)
  const [hoveredElement, setHoveredElement] = useState<string | null>(null)

  useFrame((state) => {
    if (groupRef.current) {
      // Dramatic lighting focus effect
      const contactProgress = Math.max(0, (scrollProgress - 0.66) * 3)
      groupRef.current.visible = contactProgress > 0.1
      groupRef.current.scale.setScalar(Math.min(1, contactProgress))
    }
  })

  return (
    <group ref={groupRef} position={[0, -8, 0]}>
      {/* Main contact phone */}
      <Float speed={1.2} rotationIntensity={0.1} floatIntensity={0.4}>
        <group position={[0, 0, 0]}>
          {/* Phone frame */}
          <RoundedBox args={[2.2, 4.2, 0.15]} radius={0.25} smoothness={4}>
            <meshPhysicalMaterial
              color="#1a1a2e"
              metalness={0.9}
              roughness={0.1}
              clearcoat={1}
            />
          </RoundedBox>

          {/* Screen */}
          <mesh position={[0, 0, 0.08]}>
            <planeGeometry args={[2, 4]} />
            <meshBasicMaterial color="#0a0a1a" />
          </mesh>

          {/* Screen Content via HTML */}
          <Html
            position={[0, 0, 0.09]}
            transform
            occlude
            style={{
              width: '320px',
              height: '640px',
              pointerEvents: 'none',
            }}
          >
            <div className="w-full h-full flex flex-col items-center p-4 text-white">
              <div className="text-cosmic-neon-cyan font-bold text-xl mb-4 tracking-wider">Contact</div>

              <div className="w-full space-y-3">
                <div className="w-full h-10 bg-white/10 rounded-lg border border-white/10 flex items-center px-3 text-sm text-white/40">
                  Your Name
                </div>
                <div className="w-full h-10 bg-white/10 rounded-lg border border-white/10 flex items-center px-3 text-sm text-white/40">
                  Your Email
                </div>
                <div className="w-full h-24 bg-white/10 rounded-lg border border-white/10 flex items-start p-3 text-sm text-white/40">
                  Your Message
                </div>
              </div>

              <div className="mt-4 w-full py-3 rounded-full text-center text-sm font-bold text-white"
                style={{
                  background: 'linear-gradient(135deg, #00f0ff, #b026ff)',
                  boxShadow: '0 0 20px rgba(0, 240, 255, 0.4)'
                }}
              >
                Send Message
              </div>
            </div>
          </Html>

          {/* Dynamic Island */}
          <mesh position={[0, 1.9, 0.09]}>
            <capsuleGeometry args={[0.08, 0.25, 4, 8]} />
            <meshBasicMaterial color="#000000" />
          </mesh>
        </group>
      </Float>

      {/* Floating holographic elements */}
      <Float speed={2} rotationIntensity={0.2} floatIntensity={0.6}>
        <group position={[-3.5, 1, 0]}>
          {/* Chat bubble */}
          <RoundedBox args={[1.2, 0.8, 0.05]} radius={0.1} smoothness={4}>
            <meshPhysicalMaterial
              color="#1a0a2e"
              transparent
              opacity={0.7}
              transmission={0.4}
            />
          </RoundedBox>
          <Text
            position={[0, 0, 0.03]}
            fontSize={0.15}
            color="#00f0ff"
            anchorX="center"
            anchorY="middle"
          >
            Let's Chat!
          </Text>
        </group>
      </Float>

      <Float speed={1.8} rotationIntensity={0.15} floatIntensity={0.5}>
        <group position={[3.5, -0.5, 0]}>
          {/* Instagram icon */}
          <mesh>
            <boxGeometry args={[0.8, 0.8, 0.05]} />
            <meshPhysicalMaterial
              color="#1a0a2e"
              transparent
              opacity={0.7}
            />
          </mesh>
          <Text
            position={[0, 0, 0.03]}
            fontSize={0.3}
            color="#ff00ff"
            anchorX="center"
            anchorY="middle"
          >
            📷
          </Text>
        </group>
      </Float>

      <Float speed={1.5} rotationIntensity={0.1} floatIntensity={0.4}>
        <group position={[-3, -1.5, 0]}>
          {/* Motivational text */}
          <RoundedBox args={[2, 0.6, 0.05]} radius={0.1} smoothness={4}>
            <meshPhysicalMaterial
              color="#1a0a2e"
              transparent
              opacity={0.6}
              transmission={0.3}
            />
          </RoundedBox>
          <Text
            position={[0, 0, 0.03]}
            fontSize={0.12}
            color="#b026ff"
            anchorX="center"
            anchorY="middle"
            maxWidth={1.8}
          >
            Let's Build Something Amazing
          </Text>
        </group>
      </Float>

      {/* Background particles flowing toward contact */}
      <ContactParticles />
    </group>
  )
}

function ContactParticles() {
  const particlesRef = useRef<THREE.Points>(null)
  const count = 200

  const positions = new Float32Array(count * 3)
  const velocities = new Float32Array(count * 3)

  for (let i = 0; i < count; i++) {
    const i3 = i * 3
    positions[i3] = (Math.random() - 0.5) * 20
    positions[i3 + 1] = (Math.random() - 0.5) * 20
    positions[i3 + 2] = (Math.random() - 0.5) * 10

    velocities[i3] = (Math.random() - 0.5) * 0.02
    velocities[i3 + 1] = (Math.random() - 0.5) * 0.02
    velocities[i3 + 2] = (Math.random() - 0.5) * 0.02
  }

  useFrame(() => {
    if (!particlesRef.current) return
    const posArray = particlesRef.current.geometry.attributes.position.array as Float32Array

    for (let i = 0; i < count; i++) {
      const i3 = i * 3
      // Flow toward center
      posArray[i3] += velocities[i3] - posArray[i3] * 0.001
      posArray[i3 + 1] += velocities[i3 + 1] - posArray[i3 + 1] * 0.001
      posArray[i3 + 2] += velocities[i3 + 2] - posArray[i3 + 2] * 0.001
    }

    particlesRef.current.geometry.attributes.position.needsUpdate = true
  })

  return (
    <points ref={particlesRef}>
      <bufferGeometry>
        <bufferAttribute
          attach="attributes-position"
          count={count}
          array={positions}
          itemSize={3}
        />
      </bufferGeometry>
      <pointsMaterial
        size={0.05}
        color="#00f0ff"
        transparent
        opacity={0.6}
        blending={THREE.AdditiveBlending}
      />
    </points>
  )
}
