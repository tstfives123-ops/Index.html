'use client'

import { useRef, useMemo } from 'react'
import { useFrame } from '@react-three/fiber'
import * as THREE from 'three'

interface BokehOrbsProps {
  count?: number
}

export function BokehOrbs({ count = 50 }: BokehOrbsProps) {
  const groupRef = useRef<THREE.Group>(null)

  const orbs = useMemo(() => {
    return Array.from({ length: count }, (_, i) => ({
      position: [
        (Math.random() - 0.5) * 40,
        (Math.random() - 0.5) * 30,
        (Math.random() - 0.5) * 20 - 10,
      ] as [number, number, number],
      scale: Math.random() * 0.5 + 0.2,
      color: ['#00f0ff', '#b026ff', '#ff00ff', '#ffffff'][Math.floor(Math.random() * 4)],
      speed: Math.random() * 0.5 + 0.2,
      phase: Math.random() * Math.PI * 2,
    }))
  }, [count])

  useFrame((state) => {
    if (!groupRef.current) return
    const time = state.clock.elapsedTime

    groupRef.current.children.forEach((child, i) => {
      const orb = orbs[i]
      child.position.y = orb.position[1] + Math.sin(time * orb.speed + orb.phase) * 2
      child.position.x = orb.position[0] + Math.cos(time * orb.speed * 0.7 + orb.phase) * 1
      child.scale.setScalar(
        orb.scale * (1 + Math.sin(time * orb.speed * 2 + orb.phase) * 0.2)
      )
    })
  })

  return (
    <group ref={groupRef}>
      {orbs.map((orb, i) => (
        <mesh key={i} position={orb.position}>
          <sphereGeometry args={[1, 16, 16]} />
          <meshBasicMaterial
            color={orb.color}
            transparent
            opacity={0.15}
          />
        </mesh>
      ))}
    </group>
  )
}
