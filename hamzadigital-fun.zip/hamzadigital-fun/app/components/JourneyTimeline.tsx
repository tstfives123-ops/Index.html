'use client'

import { useRef, useState, useMemo } from 'react'
import { useFrame } from '@react-three/fiber'
import { RoundedBox, Text, Float, useScroll } from '@react-three/drei'
import * as THREE from 'three'
import gsap from 'gsap'

interface JourneyCardProps {
  position: [number, number, number]
  title: string
  description: string
  icon: string
  index: number
  scrollProgress: number
}

function JourneyCard({ position, title, description, icon, index, scrollProgress }: JourneyCardProps) {
  const meshRef = useRef<THREE.Mesh>(null)
  const [hovered, setHovered] = useState(false)

  const activationThreshold = index * 0.25
  const isActive = scrollProgress > activationThreshold
  const activationProgress = Math.min(1, Math.max(0, (scrollProgress - activationThreshold) * 4))

  useFrame((state) => {
    if (!meshRef.current) return

    // Scale animation on activation
    const targetScale = isActive ? 1 : 0.8
    meshRef.current.scale.lerp(
      new THREE.Vector3(targetScale, targetScale, targetScale),
      0.05
    )

    // Glow intensity
    const glowIntensity = isActive ? 1 : 0.3

    // Subtle float
    meshRef.current.position.y = position[1] + Math.sin(state.clock.elapsedTime + index) * 0.1
  })

  return (
    <group position={position}>
      <mesh
        ref={meshRef}
        onPointerOver={() => setHovered(true)}
        onPointerOut={() => setHovered(false)}
      >
        <RoundedBox args={[3.5, 2, 0.2]} radius={0.15} smoothness={4}>
          <meshPhysicalMaterial
            color={isActive ? '#1a0a2e' : '#0a0a1a'}
            metalness={0.1}
            roughness={0.3}
            transmission={0.6}
            thickness={0.5}
            transparent
            opacity={0.8}
            emissive={isActive ? '#7c3aed' : '#000000'}
            emissiveIntensity={isActive ? 0.2 : 0}
          />
        </RoundedBox>

        {/* Border glow */}
        <mesh position={[0, 0, 0.01]}>
          <RoundedBox args={[3.55, 2.05, 0.15]} radius={0.17} smoothness={4}>
            <meshBasicMaterial
              color={isActive ? '#00f0ff' : '#7c3aed'}
              transparent
              opacity={isActive ? 0.3 : 0.1}
              side={THREE.BackSide}
            />
          </RoundedBox>
        </mesh>

        {/* Content */}
        <Text
          position={[-0.8, 0.5, 0.15]}
          fontSize={0.35}
          color={isActive ? '#00f0ff' : '#ffffff'}
          anchorX="left"
          anchorY="middle"
          font="/fonts/helvetiker_bold.typeface.json"
        >
          {icon}
        </Text>

        <Text
          position={[0, 0.2, 0.15]}
          fontSize={0.25}
          color={isActive ? '#ffffff' : '#ffffff80'}
          anchorX="center"
          anchorY="middle"
          maxWidth={3}
          font="/fonts/helvetiker_bold.typeface.json"
        >
          {title}
        </Text>

        <Text
          position={[0, -0.3, 0.15]}
          fontSize={0.12}
          color="#ffffff60"
          anchorX="center"
          anchorY="middle"
          maxWidth={3}
          font="/fonts/helvetiker_regular.typeface.json"
        >
          {description}
        </Text>

        {/* Connection dot */}
        <mesh position={[0, -1.2, 0]}>
          <sphereGeometry args={[0.08, 16, 16]} />
          <meshBasicMaterial
            color={isActive ? '#00f0ff' : '#7c3aed'}
            transparent
            opacity={isActive ? 1 : 0.3}
          />
        </mesh>
      </mesh>
    </group>
  )
}

interface LightBeamProps {
  start: [number, number, number]
  end: [number, number, number]
  progress: number
  color?: string
}

function LightBeam({ start, end, progress, color = '#00f0ff' }: LightBeamProps) {
  const beamRef = useRef<THREE.Mesh>(null)

  const curve = useMemo(() => {
    return new THREE.CatmullRomCurve3([
      new THREE.Vector3(...start),
      new THREE.Vector3(
        (start[0] + end[0]) / 2,
        (start[1] + end[1]) / 2 - 0.5,
        (start[2] + end[2]) / 2
      ),
      new THREE.Vector3(...end),
    ])
  }, [start, end])

  const tubeGeometry = useMemo(() => {
    return new THREE.TubeGeometry(curve, 64, 0.02, 8, false)
  }, [curve])

  useFrame(() => {
    if (beamRef.current) {
      beamRef.current.scale.setScalar(Math.min(1, progress * 2))
    }
  })

  if (progress <= 0) return null

  return (
    <mesh ref={beamRef} geometry={tubeGeometry}>
      <meshBasicMaterial
        color={color}
        transparent
        opacity={Math.min(0.6, progress)}
        blending={THREE.AdditiveBlending}
      />
    </mesh>
  )
}

interface JourneyTimelineProps {
  scrollProgress: number
}

export function JourneyTimeline({ scrollProgress }: JourneyTimelineProps) {
  const cards = [
    {
      position: [-2, 4, 0] as [number, number, number],
      title: 'Childhood Curiosity',
      description: 'Where it all began - exploring the world with wonder and imagination',
      icon: '🌱',
    },
    {
      position: [2, 2, 0] as [number, number, number],
      title: 'First Internet Experience',
      description: 'Discovering the digital realm and its infinite possibilities',
      icon: '🌐',
    },
    {
      position: [-2, 0, 0] as [number, number, number],
      title: 'Academic Awakening',
      description: 'Formal education meeting creative passion in design and code',
      icon: '🎓',
    },
    {
      position: [2, -2, 0] as [number, number, number],
      title: 'Building Futuristic Digital Experiences',
      description: 'Creating immersive worlds that push the boundaries of web technology',
      icon: '🚀',
    },
  ]

  return (
    <group>
      {cards.map((card, i) => (
        <JourneyCard
          key={i}
          {...card}
          index={i}
          scrollProgress={scrollProgress}
        />
      ))}

      {/* Connecting light beams */}
      {cards.map((card, i) => {
        if (i === cards.length - 1) return null
        const nextCard = cards[i + 1]
        const beamProgress = Math.max(0, (scrollProgress - i * 0.25) * 4)
        return (
          <LightBeam
            key={`beam-${i}`}
            start={[card.position[0], card.position[1] - 1.2, card.position[2]]}
            end={[nextCard.position[0], nextCard.position[1] + 1, nextCard.position[2]]}
            progress={beamProgress}
            color={i % 2 === 0 ? '#00f0ff' : '#b026ff'}
          />
        )
      })}
    </group>
  )
}
