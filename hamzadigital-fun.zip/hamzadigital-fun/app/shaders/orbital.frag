uniform vec3 uColor;
uniform float uTime;

varying vec2 vUv;
varying float vAlpha;

void main() {
  float glow = smoothstep(0.5, 0.0, abs(vUv.y - 0.5));
  float pulse = sin(uTime * 2.0 + vUv.x * 10.0) * 0.3 + 0.7;

  vec3 color = uColor * glow * pulse;
  float alpha = glow * vAlpha * 0.8;

  gl_FragColor = vec4(color, alpha);
}
