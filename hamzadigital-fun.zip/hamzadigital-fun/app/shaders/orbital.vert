uniform float uTime;
uniform float uProgress;

varying vec2 vUv;
varying float vAlpha;

void main() {
  vUv = uv;

  vec3 pos = position;
  float trail = smoothstep(0.0, 1.0, uProgress - uv.x * 0.5);
  vAlpha = trail;

  gl_Position = projectionMatrix * modelViewMatrix * vec4(pos, 1.0);
}
