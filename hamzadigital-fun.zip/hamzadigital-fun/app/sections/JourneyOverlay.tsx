'use client'

import { useEffect, useRef } from 'react'
import gsap from 'gsap'
import { ScrollTrigger } from 'gsap/ScrollTrigger'

const milestones = [
  {
    year: '2008',
    title: 'Childhood Curiosity',
    description: 'First lines of code written, sparking a lifelong passion for digital creation.',
    icon: '🌱',
  },
  {
    year: '2012',
    title: 'First Internet Experience',
    description: 'Discovered the power of the web and its infinite creative possibilities.',
    icon: '🌐',
  },
  {
    year: '2016',
    title: 'Academic Awakening',
    description: 'Formal education in design and development merged with creative vision.',
    icon: '🎓',
  },
  {
    year: '2020',
    title: 'Building the Future',
    description: 'Creating immersive digital experiences that push technological boundaries.',
    icon: '🚀',
  },
]

export function JourneyOverlay() {
  const containerRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    gsap.registerPlugin(ScrollTrigger)

    const ctx = gsap.context(() => {
      milestones.forEach((_, i) => {
        gsap.from(`.milestone-${i}`, {
          scrollTrigger: {
            trigger: `.milestone-${i}`,
            start: 'top 80%',
            end: 'top 30%',
            scrub: 1,
          },
          x: i % 2 === 0 ? -100 : 100,
          opacity: 0,
          scale: 0.8,
        })
      })
    }, containerRef)

    return () => ctx.revert()
  }, [])

  return (
    <div ref={containerRef} className="relative z-10 min-h-screen py-32 pointer-events-none">
      <div className="max-w-4xl mx-auto px-6">
        <div className="text-center mb-20">
          <h2 className="text-4xl md:text-6xl font-bold mb-4">
            <span className="gradient-text">MY JOURNEY</span>
          </h2>
          <p className="text-white/50 text-lg">The path that shaped a digital creator</p>
        </div>

        <div className="relative">
          {/* Timeline line */}
          <div className="absolute left-1/2 top-0 bottom-0 w-px bg-gradient-to-b from-cosmic-neon-cyan via-cosmic-neon-purple to-cosmic-neon-magenta opacity-30" />

          <div className="space-y-24">
            {milestones.map((milestone, i) => (
              <div
                key={i}
                className={`milestone-${i} relative flex items-center gap-8 ${
                  i % 2 === 0 ? 'flex-row' : 'flex-row-reverse'
                }`}
              >
                <div className={`flex-1 ${i % 2 === 0 ? 'text-right' : 'text-left'}`}>
                  <div className="glass-card inline-block p-6 rounded-2xl max-w-md pointer-events-auto hover:scale-105 transition-transform duration-300">
                    <div className="flex items-center gap-3 mb-3">
                      <span className="text-2xl">{milestone.icon}</span>
                      <span className="text-cosmic-neon-cyan font-mono text-sm">{milestone.year}</span>
                    </div>
                    <h3 className="text-xl font-bold text-white mb-2">{milestone.title}</h3>
                    <p className="text-white/60 text-sm leading-relaxed">{milestone.description}</p>
                  </div>
                </div>

                {/* Center dot */}
                <div className="relative z-10 w-4 h-4 rounded-full bg-cosmic-neon-cyan shadow-[0_0_20px_#00f0ff]" />

                <div className="flex-1" />
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}
