'use client'

import { useState, useEffect, useRef } from 'react'
import gsap from 'gsap'
import { ScrollTrigger } from 'gsap/ScrollTrigger'

export function ContactOverlay() {
  const containerRef = useRef<HTMLDivElement>(null)
  const [formData, setFormData] = useState({ name: '', email: '', message: '' })
  const [submitted, setSubmitted] = useState(false)

  useEffect(() => {
    gsap.registerPlugin(ScrollTrigger)

    const ctx = gsap.context(() => {
      gsap.from('.contact-content', {
        scrollTrigger: {
          trigger: '.contact-section',
          start: 'top 80%',
          end: 'top 30%',
          scrub: 1,
        },
        y: 100,
        opacity: 0,
      })
    }, containerRef)

    return () => ctx.revert()
  }, [])

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    setSubmitted(true)
    setTimeout(() => setSubmitted(false), 3000)
  }

  return (
    <div ref={containerRef} className="contact-section relative z-10 min-h-screen flex items-center justify-center py-32 pointer-events-none">
      <div className="contact-content max-w-2xl mx-auto px-6 w-full pointer-events-auto">
        <div className="text-center mb-12">
          <h2 className="text-4xl md:text-6xl font-bold mb-4">
            <span className="gradient-text">LET'S CONNECT</span>
          </h2>
          <p className="text-white/50 text-lg">Ready to build something extraordinary?</p>
        </div>

        <div className="glass-panel rounded-3xl p-8 md:p-12">
          {submitted ? (
            <div className="text-center py-12">
              <div className="text-6xl mb-4">✨</div>
              <h3 className="text-2xl font-bold text-cosmic-neon-cyan mb-2">Message Sent!</h3>
              <p className="text-white/60">Thank you for reaching out. I'll get back to you soon.</p>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-6">
              <div>
                <label className="block text-white/60 text-sm mb-2">Name</label>
                <input
                  type="text"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white placeholder-white/30 focus:outline-none focus:border-cosmic-neon-cyan/50 focus:shadow-[0_0_20px_rgba(0,240,255,0.1)] transition-all"
                  placeholder="Your name"
                  required
                />
              </div>

              <div>
                <label className="block text-white/60 text-sm mb-2">Email</label>
                <input
                  type="email"
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white placeholder-white/30 focus:outline-none focus:border-cosmic-neon-cyan/50 focus:shadow-[0_0_20px_rgba(0,240,255,0.1)] transition-all"
                  placeholder="your@email.com"
                  required
                />
              </div>

              <div>
                <label className="block text-white/60 text-sm mb-2">Message</label>
                <textarea
                  value={formData.message}
                  onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                  className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white placeholder-white/30 focus:outline-none focus:border-cosmic-neon-cyan/50 focus:shadow-[0_0_20px_rgba(0,240,255,0.1)] transition-all resize-none"
                  rows={5}
                  placeholder="Tell me about your project..."
                  required
                />
              </div>

              <button
                type="submit"
                className="btn-glow w-full py-4 rounded-xl text-white font-bold text-lg transition-all duration-300 hover:scale-[1.02]"
                style={{
                  background: 'linear-gradient(135deg, #00f0ff, #b026ff)',
                  boxShadow: '0 0 30px rgba(0, 240, 255, 0.3)',
                }}
              >
                Send Message
              </button>
            </form>
          )}
        </div>

        {/* Social links */}
        <div className="flex justify-center gap-6 mt-12">
          {[
            { icon: '📷', label: 'Instagram', color: '#ff00ff' },
            { icon: '🐦', label: 'Twitter', color: '#00f0ff' },
            { icon: '💼', label: 'LinkedIn', color: '#b026ff' },
            { icon: '📧', label: 'Email', color: '#00f0ff' },
          ].map((social, i) => (
            <button
              key={i}
              className="w-12 h-12 rounded-full glass-card flex items-center justify-center text-xl hover:scale-110 transition-all duration-300"
              style={{
                boxShadow: `0 0 15px ${social.color}30`,
              }}
              title={social.label}
            >
              {social.icon}
            </button>
          ))}
        </div>

        <p className="text-center text-white/30 text-sm mt-8">
          Let's Build Something Amazing Together
        </p>
      </div>
    </div>
  )
}
