'use client'

import { useEffect, useRef } from 'react'
import gsap from 'gsap'
import { ScrollTrigger } from 'gsap/ScrollTrigger'

export function HeroOverlay() {
  const containerRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    gsap.registerPlugin(ScrollTrigger)

    const ctx = gsap.context(() => {
      gsap.from('.hero-title', {
        y: 100,
        opacity: 0,
        duration: 1.5,
        ease: 'power3.out',
        delay: 0.5,
      })

      gsap.from('.hero-subtitle', {
        y: 50,
        opacity: 0,
        duration: 1.2,
        ease: 'power3.out',
        delay: 0.8,
      })

      gsap.from('.hero-cta', {
        y: 30,
        opacity: 0,
        duration: 1,
        ease: 'power3.out',
        delay: 1.2,
      })

      // Fade out on scroll
      gsap.to('.hero-content', {
        scrollTrigger: {
          trigger: '.hero-section',
          start: 'top top',
          end: 'bottom top',
          scrub: true,
        },
        opacity: 0,
        y: -100,
      })
    }, containerRef)

    return () => ctx.revert()
  }, [])

  return (
    <div ref={containerRef} className="hero-section relative z-10 min-h-screen flex items-center justify-center pointer-events-none">
      <div className="hero-content text-center pointer-events-auto">
        <h1 className="hero-title text-6xl md:text-8xl font-bold tracking-tight mb-4">
          <span className="gradient-text">DIGITAL</span>
          <br />
          <span className="text-white">ARCHITECT</span>
        </h1>

        <p className="hero-subtitle text-xl md:text-2xl text-white/70 font-light tracking-wide mb-8">
          & CREATIVE MIND
        </p>

        <div className="hero-cta flex flex-col items-center gap-4">
          <button
            className="btn-glow px-8 py-4 rounded-full text-white font-semibold text-lg transition-all duration-300 hover:scale-105"
            style={{
              background: 'linear-gradient(135deg, #00f0ff, #b026ff)',
              boxShadow: '0 0 30px rgba(0, 240, 255, 0.4), 0 0 60px rgba(176, 38, 255, 0.2)',
            }}
            onClick={() => {
              const docHeight = document.documentElement.scrollHeight - window.innerHeight
              window.scrollTo({ top: docHeight * 0.5, behavior: 'smooth' })
            }}
          >
            EXPLORE JOURNEY
          </button>

          <p className="text-white/40 text-sm tracking-widest uppercase">
            Scroll to discover
          </p>
        </div>
      </div>

      {/* Corner decorations */}
      <div className="absolute top-8 left-8 text-white/20 text-xs tracking-widest">
        <div className="flex items-center gap-2">
          <div className="w-2 h-2 rounded-full bg-cosmic-neon-cyan animate-pulse" />
          <span>LIVE</span>
        </div>
      </div>

      <div className="absolute bottom-8 right-8 text-white/20 text-xs">
        <div className="flex flex-col items-end gap-1">
          <span>2026</span>
          <span>hamzadigital.fun</span>
        </div>
      </div>
    </div>
  )
}
