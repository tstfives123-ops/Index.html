'use client'

import { useEffect, useState } from 'react'
import { Inter, Space_Grotesk } from 'next/font/google'
import './globals.css'

const inter = Inter({ subsets: ['latin'], variable: '--font-inter' })
const spaceGrotesk = Space_Grotesk({ subsets: ['latin'], variable: '--font-space-grotesk' })

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    // Simulate asset loading
    const timer = setTimeout(() => {
      setLoading(false)
    }, 2000)
    return () => clearTimeout(timer)
  }, [])

  return (
    <html lang="en" className={`${inter.variable} ${spaceGrotesk.variable}`}>
      <head>
        <title>Hamza Digital | Creative Architect</title>
        <meta name="description" content="Premium immersive 3D portfolio of Hamza - Digital Architect & Creative Mind" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
      </head>
      <body className="font-sans antialiased">
        {/* Loading Screen */}
        <div className={`loading-screen ${!loading ? 'hidden' : ''}`}>
          <div className="flex flex-col items-center gap-6">
            <div className="relative">
              <div className="w-16 h-16 rounded-full border-2 border-transparent border-t-cosmic-neon-cyan border-r-cosmic-neon-purple animate-spin" />
              <div className="absolute inset-0 flex items-center justify-center">
                <span className="text-cosmic-neon-cyan font-bold text-xl">H</span>
              </div>
            </div>
            <p className="text-white/60 text-sm tracking-widest uppercase">Loading Universe</p>
          </div>
        </div>
        {children}
      </body>
    </html>
  )
}
