'use client'

import { useRef, useState, useEffect } from 'react'

export function useMouseParallax(intensity: number = 0.02) {
  const [mousePosition, setMousePosition] = useState({ x: 0, y: 0 })
  const targetRef = useRef({ x: 0, y: 0 })
  const rafRef = useRef<number>()

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      targetRef.current = {
        x: (e.clientX / window.innerWidth - 0.5) * intensity,
        y: (e.clientY / window.innerHeight - 0.5) * intensity,
      }
    }

    const handleDeviceOrientation = (e: DeviceOrientationEvent) => {
      if (e.gamma && e.beta) {
        targetRef.current = {
          x: (e.gamma / 90) * intensity * 2,
          y: (e.beta / 90) * intensity * 2,
        }
      }
    }

    const animate = () => {
      setMousePosition(prev => ({
        x: prev.x + (targetRef.current.x - prev.x) * 0.05,
        y: prev.y + (targetRef.current.y - prev.y) * 0.05,
      }))
      rafRef.current = requestAnimationFrame(animate)
    }

    window.addEventListener('mousemove', handleMouseMove)
    window.addEventListener('deviceorientation', handleDeviceOrientation)
    rafRef.current = requestAnimationFrame(animate)

    return () => {
      window.removeEventListener('mousemove', handleMouseMove)
      window.removeEventListener('deviceorientation', handleDeviceOrientation)
      if (rafRef.current) cancelAnimationFrame(rafRef.current)
    }
  }, [intensity])

  return mousePosition
}
