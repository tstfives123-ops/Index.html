'use client'

import { useEffect, useState } from 'react'

export function useScrollProgress() {
  const [progress, setProgress] = useState(0)
  const [section, setSection] = useState(0)

  useEffect(() => {
    const handleScroll = () => {
      const scrollTop = window.scrollY
      const docHeight = document.documentElement.scrollHeight - window.innerHeight
      const scrollProgress = scrollTop / docHeight
      setProgress(scrollProgress)

      // Determine current section (0, 1, 2)
      const sectionHeight = docHeight / 3
      const currentSection = Math.min(2, Math.floor(scrollTop / sectionHeight))
      setSection(currentSection)
    }

    window.addEventListener('scroll', handleScroll, { passive: true })
    return () => window.removeEventListener('scroll', handleScroll)
  }, [])

  return { progress, section }
}
