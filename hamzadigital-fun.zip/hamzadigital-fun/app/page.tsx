'use client'

import { useEffect, Suspense, lazy } from 'react'
import { Canvas } from '@react-three/fiber'
import { useSmoothScroll } from './hooks/useSmoothScroll'
import { useMouseParallax } from './hooks/useMouseParallax'
import { useScrollProgress } from './hooks/useScrollProgress'
import { Navigation } from './components/Navigation'
import { HeroOverlay } from './sections/HeroOverlay'
import { JourneyOverlay } from './sections/JourneyOverlay'
import { ContactOverlay } from './sections/ContactOverlay'

// Lazy load the 3D scene for better performance
const Scene = lazy(() => import('./components/Scene').then(mod => ({ default: mod.Scene })))

function LoadingFallback() {
  return (
    <div className="fixed inset-0 flex items-center justify-center bg-cosmic-black z-0">
      <div className="text-cosmic-neon-cyan text-lg animate-pulse">Loading 3D Universe...</div>
    </div>
  )
}

export default function Home() {
  useSmoothScroll()
  const mousePosition = useMouseParallax(0.02)
  const { progress, section } = useScrollProgress()

  return (
    <main className="relative bg-cosmic-black">
      {/* 3D Canvas Background */}
      <div className="fixed inset-0 z-0">
        <Canvas
          camera={{ position: [0, 0, 8], fov: 60, near: 0.1, far: 200 }}
          dpr={[1, 2]}
          gl={{
            antialias: true,
            alpha: true,
            powerPreference: 'high-performance',
          }}
          style={{ background: 'transparent' }}
        >
          <Suspense fallback={null}>
            <Scene scrollProgress={progress} mousePosition={mousePosition} section={section} />
          </Suspense>
        </Canvas>
      </div>

      {/* Navigation */}
      <Navigation section={section} scrollProgress={progress} />

      {/* Scrollable Content */}
      <div className="relative z-10">
        {/* Hero Section */}
        <section id="hero" className="min-h-screen">
          <HeroOverlay />
        </section>

        {/* Journey Section */}
        <section id="journey" className="min-h-screen">
          <JourneyOverlay />
        </section>

        {/* Contact Section */}
        <section id="contact" className="min-h-screen">
          <ContactOverlay />
        </section>

        {/* Footer */}
        <footer className="relative z-10 py-12 text-center">
          <div className="glass-panel mx-8 rounded-2xl py-8 px-6">
            <p className="text-white/40 text-sm">
              © 2026 Hamza Digital. Crafted with cosmic precision.
            </p>
            <div className="flex justify-center gap-4 mt-4">
              <span className="text-cosmic-neon-cyan text-xs">React Three Fiber</span>
              <span className="text-white/20 text-xs">•</span>
              <span className="text-cosmic-neon-purple text-xs">GSAP</span>
              <span className="text-white/20 text-xs">•</span>
              <span className="text-cosmic-neon-magenta text-xs">Three.js</span>
            </div>
          </div>
        </footer>
      </div>
    </main>
  )
}
