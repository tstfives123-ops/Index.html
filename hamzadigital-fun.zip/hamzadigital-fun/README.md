# Hamza Digital - Premium Immersive 3D Portfolio

A premium immersive single-page 3D website for hamzadigital.fun built with Next.js 15, React Three Fiber, Three.js, GSAP, and Lenis.

## Features

### 3D Environment
- **Deep Cosmic Space**: 10,000+ twinkling star particles with mouse-reactive parallax
- **Volumetric Nebulae**: Purple-cyan-magenta nebulae with custom shader noise
- **Floating Bokeh Orbs**: Animated glowing orbs throughout the scene
- **Floating Debris**: Subtle geometric debris with slow rotation

### Lighting & Effects
- **Cinematic Lighting**: Multiple colored point lights, spot lights for god rays
- **Post-Processing**: Bloom, chromatic aberration, vignette, SMAA anti-aliasing
- **Volumetric Effects**: Simulated god rays and atmospheric glow

### Sections
1. **Hero Section**: 
   - Massive 3D HMZ logo with metallic/iridescent material
   - Animated orbital rings with glow
   - Floating iPhone 16 Pro mockup
   - "DIGITAL ARCHITECT & CREATIVE MIND" branding

2. **Journey Section**:
   - 4 glassmorphic timeline cards with scroll-triggered activation
   - Animated connecting light beams (CatmullRomCurve3)
   - iPhone mockup showing journey view

3. **Contact Section**:
   - Dramatic lighting focus
   - iPhone mockup with futuristic contact form
   - Holographic floating elements (chat bubbles, Instagram icon)
   - Flowing background particles

### Interactions
- **Raycasting Hover**: Cards, phones, and buttons respond to hover
- **Neon Intensity**: Glow effects intensify on interaction
- **Particle Bursts**: Button interactions trigger particle effects
- **Mouse Parallax**: Scene reacts to mouse movement
- **Device Orientation**: Mobile gyroscope support

### Performance
- **60fps Optimized**: InstancedMesh for particles, LOD, geometry disposal
- **Lazy Loading**: 3D scene loaded via React Suspense
- **Proper Asset Management**: Suspended heavy assets with fallback UI

## Tech Stack

- **Framework**: Next.js 15 (App Router)
- **3D Engine**: React Three Fiber + Three.js
- **Animation**: GSAP + ScrollTrigger
- **Smooth Scroll**: Lenis
- **Styling**: Tailwind CSS
- **Post-Processing**: @react-three/postprocessing
- **Fonts**: Space Grotesk, Inter

## Getting Started

### Prerequisites
- Node.js 18+
- npm or yarn

### Installation

```bash
# Clone or extract the project
cd hamzadigital-fun

# Install dependencies
npm install

# Run development server
npm run dev

# Build for production
npm run build
```

### Important Notes

1. **Fonts**: The project uses Space Grotesk and Inter from Google Fonts (loaded via CSS import)
2. **3D Text**: Text3D components require font files. Place `helvetiker_bold.typeface.json` and `helvetiker_regular.typeface.json` in `/public/fonts/`
3. **Performance**: For optimal performance, ensure WebGL is enabled in your browser

### File Structure

```
hamzadigital-fun/
├── app/
│   ├── components/          # 3D React components
│   │   ├── Starfield.tsx
│   │   ├── Nebula.tsx
│   │   ├── BokehOrbs.tsx
│   │   ├── HMZLogo.tsx
│   │   ├── iPhoneMockup.tsx
│   │   ├── JourneyTimeline.tsx
│   │   ├── ContactSection.tsx
│   │   ├── Scene.tsx
│   │   └── Navigation.tsx
│   ├── sections/            # HTML overlay sections
│   │   ├── HeroOverlay.tsx
│   │   ├── JourneyOverlay.tsx
│   │   └── ContactOverlay.tsx
│   ├── hooks/               # Custom React hooks
│   │   ├── useSmoothScroll.ts
│   │   ├── useMouseParallax.ts
│   │   └── useScrollProgress.ts
│   ├── shaders/             # GLSL shaders
│   │   ├── vertex.glsl
│   │   ├── fragment.glsl
│   │   ├── orbital.vert
│   │   └── orbital.frag
│   ├── globals.css
│   ├── layout.tsx
│   └── page.tsx
├── public/
│   └── fonts/
│       ├── helvetiker_bold.typeface.json
│       └── helvetiker_regular.typeface.json
├── next.config.js
├── tailwind.config.js
├── tsconfig.json
└── package.json
```

## Customization

### Colors
Edit the CSS variables in `globals.css`:
```css
:root {
  --cosmic-black: #050510;
  --cosmic-dark: #0a0a1a;
  --neon-cyan: #00f0ff;
  --neon-purple: #b026ff;
  --neon-magenta: #ff00ff;
}
```

### Journey Milestones
Edit the milestones array in `app/sections/JourneyOverlay.tsx`:
```typescript
const milestones = [
  {
    year: '2008',
    title: 'Childhood Curiosity',
    description: 'Your description here',
    icon: '🌱',
  },
  // ...
]
```

### Contact Information
Update the social links and contact details in `app/sections/ContactOverlay.tsx`.

## Browser Support

- Chrome 90+
- Firefox 88+
- Safari 14+
- Edge 90+

## Performance Tips

1. Reduce particle count on mobile devices
2. Use `dpr={[1, 1.5]}` instead of `[1, 2]` for lower-end devices
3. Disable post-processing effects on mobile if needed
4. Use `React.memo` for static components

## License

MIT License - feel free to use this template for your own portfolio!

---

Built with cosmic precision by Hamza Digital 🚀
